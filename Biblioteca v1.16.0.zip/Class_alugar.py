class alugar():
    def __init__(self, id_livro,id_cliente):
        self.id_livro=id_livro
        self.id_cliente=id_cliente